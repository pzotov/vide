/*
 * Entry file for JS
 * Babel is used to transpile into ES5
 */
"use strict";

// ...
